<?php
session_start(); 

function conectarDB() {
    $serverName = "DESKTOP-IJP72TQ\\SQLL"; // Cambia esto por el nombre de tu servidor
    $database = "tienda"; // Cambia esto por tu base de datos
    $username = "tienda"; // Cambia esto por tu usuario
    $password = "1234"; // Cambia esto por tu contraseña

    try {
        $conn = new PDO("sqlsrv:server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

function crearUsuario($conn, $nombre, $apellido, $documento, $telefono, $direccion) {
    $contrasena_encriptada = password_hash($documento, PASSWORD_DEFAULT);
    $sql = "INSERT INTO usuarios (nombre, apellido, documento, telefono, direccion) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([$nombre, $apellido, $contrasena_encriptada, $telefono, $direccion]);
}

function leerUsuarios($conn) {
    $sql = "SELECT * FROM usuarios";
    $stmt = $conn->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function actualizarUsuario($conn, $id, $nombre, $apellido, $documento, $telefono, $direccion) {
    $contrasena_encriptada = password_hash($documento, PASSWORD_DEFAULT);
    $sql = "UPDATE usuarios SET nombre = ?, apellido = ?, documento = ?, telefono = ?, direccion = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([$nombre, $apellido, $contrasena_encriptada, $telefono, $direccion, $id]);
}

function eliminarUsuario($conn, $id) {
    $sql = "DELETE FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($sql);
    return $stmt->execute([$id]);
}

$conn = conectarDB();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $accion = $_POST["accion"];
    if ($accion == "crear") {
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $documento = $_POST["documento"];
        $telefono = $_POST["telefono"];
        $direccion = $_POST["direccion"];
        if (crearUsuario($conn, $nombre, $apellido, $documento, $telefono, $direccion)) {
            echo "Registro exitoso";
        } else {
            echo "Error en el registro";
        }
    } elseif ($accion == "actualizar") {
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $documento = $_POST["documento"];
        $telefono = $_POST["telefono"];
        $direccion = $_POST["direccion"];
        if (actualizarUsuario($conn, $id, $nombre, $apellido, $documento, $telefono, $direccion)) {
            echo "Actualización exitosa";
        } else {
            echo "Error en la actualización";
        }
    } elseif ($accion == "eliminar") {
        $id = $_POST["id"];
        if (eliminarUsuario($conn, $id)) {
            echo "Eliminación exitosa";
        } else {
            echo "Error en la eliminación";
        }
    }
}

$usuarios = leerUsuarios($conn);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD de Usuarios</title>
</head>
<body>
    <h2>Formulario de Registro</h2>
    <form action="" method="post">
        <input type="hidden" name="accion" value="crear">
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" required><br><br>

        <label for="apellido">Apellido:</label><br>
        <input type="text" id="apellido" name="apellido" required><br><br>

        <label for="documento">Documento:</label><br>
        <input type="password" id="documento" name="documento" required><br><br>

        <label for="telefono">Teléfono:</label><br>
        <input type="text" id="telefono" name="telefono" required><br><br>

        <label for="direccion">Dirección:</label><br>
        <input type="text" id="direccion" name="direccion" required><br><br>

        <input type="submit" value="Registrarse">
    </form>

    <h2>Lista de Usuarios</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Documento</th>
            <th>Teléfono</th>
            <th>Dirección</th>
            <th>Acciones</th>
        </tr>
        <?php foreach ($usuarios as $usuario): ?>
        <tr>
            <td><?php echo $usuario['id']; ?></td>
            <td><?php echo $usuario['nombre']; ?></td>
            <td><?php echo $usuario['apellido']; ?></td>
            <td><?php echo $usuario['documento']; ?></td>
            <td><?php echo $usuario['telefono']; ?></td>
            <td><?php echo $usuario['direccion']; ?></td>
            <td>
                <form action="" method="post" style="display:inline;">
                    <input type="hidden" name="accion" value="eliminar">
                    <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
                    <input type="submit" value="Eliminar">
                </form>
                <form action="" method="post" style="display:inline;">
                    <input type="hidden" name="accion" value="actualizar">
                    <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
                    <input type="text" name="nombre" value="<?php echo $usuario['nombre']; ?>" required>
                    <input type="text" name="apellido" value="<?php echo $usuario['apellido']; ?>" required>
                    <input type="password" name="documento" value="<?php echo $usuario['documento']; ?>" required>
                    <input type="text" name="telefono" value="<?php echo $usuario['telefono']; ?>" required>
                    <input type="text" name="direccion" value="<?php echo $usuario['direccion']; ?>" required>
                    <input type="submit" value="Actualizar">
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
<?php
$conn = null; // Cerrar la conexión
?>
