<?php
session_start(); 

function conectarDB() {
    $serverName = "DESKTOP-9N083QB\SQLEXPRESS"; // Cambia esto por el nombre de tu servidor
    $database = "ProyectoPIA"; // Cambia esto por tu base de datos
    $username = "Usuario_Samuel"; // Cambia esto por tu usuario
    $password = "12345"; // Cambia esto por tu contraseña

    try {
        $conn = new PDO("sqlsrv:server=$serverName;Database=$database", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

$conn = conectarDB();

// Operación Crear Usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'crear') {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $tpUsuario = $_POST['tpUsuario'];

    try {
        $sql = "INSERT INTO tabla_registro (Nombre, Email, Telefono, Direccion, TP_Usuario) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$nombre, $email, $telefono, $direccion, $tpUsuario]);
        echo "Usuario registrado exitosamente.";
    } catch (PDOException $e) {
        echo "Error al registrar el usuario: " . $e->getMessage();
    }
}

// Operación Leer Usuarios
function leerUsuarios($conn) {
    try {
        $sql = "SELECT * FROM tabla_registro";
        $stmt = $conn->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error al leer los usuarios: " . $e->getMessage();
        return [];
    }
}

$usuarios = leerUsuarios($conn);

// Operación Actualizar Usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'actualizar') {
    $ID = $_POST['ID'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $tpUsuario = $_POST['tpUsuario'];

    try {
        $sql = "UPDATE tabla_registro SET Nombre = ?, Email = ?, Telefono = ?, Direccion = ?, TP_Usuario = ? WHERE ID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$nombre, $email, $telefono, $direccion, $tpUsuario, $ID]);
        echo "Usuario actualizado exitosamente.";
    } catch (PDOException $e) {
        echo "Error al actualizar el usuario: " . $e->getMessage();
    }
}

// Operación Eliminar Usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'eliminar') {
    $ID = $_POST['ID'];

    try {
        $sql = "DELETE FROM tabla_registro WHERE ID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$ID]);
        echo "Usuario eliminado exitosamente.";
    } catch (PDOException $e) {
        echo "Error al eliminar el usuario: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario y Alumnos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        h2 {
            color: #333;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }
        input[type="text"], input[type="email"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .action-buttons form {
            display: inline;
        }
        .update-button, .delete-button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
        .delete-button {
            background-color: #dc3545;
        }
        .update-button:hover {
            background-color: #0056b3;
        }
        .delete-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <h2>Registro de Usuario</h2>
    <form action="" method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="telefono">Teléfono:</label>
        <input type="text" id="telefono" name="telefono" required>
        
        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" required>
        
        <label for="tpUsuario">Tipo de Usuario:</label>
        <input type="text" id="tpUsuario" name="tpUsuario" required>

        <input type="hidden" name="accion" value="crear">
        <input type="submit" value="Registrar">
    </form>

    <h2>Lista de Usuarios</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>Tipo de Usuario</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?php echo $usuario['ID']; ?></td>
                    <td><?php echo $usuario['Nombre']; ?></td>
                    <td><?php echo $usuario['Email']; ?></td>
                    <td><?php echo $usuario['Telefono']; ?></td>
                    <td><?php echo $usuario['Direccion']; ?></td>
                    <td><?php echo $usuario['TP_Usuario']; ?></td>
                    <td class="action-buttons">
                        <form action="" method="post" style="display:inline;">
                            <input type="hidden" name="ID" value="<?php echo $usuario['ID']; ?>">
                            <input type="hidden" name="nombre" value="<?php echo $usuario['Nombre']; ?>">
                            <input type="hidden" name="email" value="<?php echo $usuario['Email']; ?>">
                            <input type="hidden" name="telefono" value="<?php echo $usuario['Telefono']; ?>">
                            <input type="hidden" name="direccion" value="<?php echo $usuario['Direccion']; ?>">
                            <input type="hidden" name="tpUsuario" value="<?php echo $usuario['TP_Usuario']; ?>">
                            <input type="hidden" name="accion" value="actualizar">
                            <button type="submit" class="update-button">Actualizar</button>
                        </form>
                        <form action="" method="post" style="display:inline;">
                            <input type="hidden" name="ID" value="<?php echo $usuario['ID']; ?>">
                            <input type="hidden" name="accion" value="eliminar">
                            <button type="submit" class="delete-button">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
