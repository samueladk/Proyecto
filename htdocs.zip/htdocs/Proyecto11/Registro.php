<?php
function conectarDB() {
    $serverName = "DESKTOP-9N083QB\\SQLEXPRESS"; 
    $connectionOptions = array(
        "Database" => "ProyectoPIA", 
        "Uid" => "Usuario_Samuel", 
        "PWD" => "12345" 
    );
    try {
        $conn = new PDO("sqlsrv:server=$serverName;Database=" . $connectionOptions['Database'], $connectionOptions['Uid'], $connectionOptions['PWD']);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Error de conexión: " . $e->getMessage());
    }
}

$conn = conectarDB();

// Operación Crear Usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'crear') {
    $nombre = $_POST['nombre'];
    $tipoUsuario = $_POST['tipoUsuario'];
    $email = $_POST['email'];

    try {
        $sql = "INSERT INTO Tabla_usuarios (Nombre, TipoUsuario, Email) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$nombre, $tipoUsuario, $email]);
        echo "Usuario registrado exitosamente.";
    } catch (PDOException $e) {
        echo "Error al registrar el usuario: " . $e->getMessage();
    }
}

// Operación Leer Usuarios
function leerUsuarios($conn) {
    try {
        $sql = "SELECT * FROM Tabla_usuarios";
        $stmt = $conn->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error al leer los usuarios: " . $e->getMessage();
        return [];
    }
}

$usuarios = leerUsuarios($conn);

// Operación Actualizar Usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'actualizar') {
    $UsuarioID = $_POST['UsuarioID'];
    $nombre = $_POST['nombre'];
    $tipoUsuario = $_POST['tipoUsuario'];
    $email = $_POST['email'];

    try {
        $sql = "UPDATE Tabla_usuarios SET Nombre = ?, TipoUsuario = ?, Email = ? WHERE UsuarioID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$nombre, $tipoUsuario, $email, $UsuarioID]);
        echo "Usuario actualizado exitosamente.";
    } catch (PDOException $e) {
        echo "Error al actualizar el usuario: " . $e->getMessage();
    }
}

// Operación Eliminar Usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'eliminar') {
    $UsuarioID = $_POST['UsuarioID'];

    try {
        $sql = "DELETE FROM Tabla_usuarios WHERE UsuarioID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$UsuarioID]);
        echo "Usuario eliminado exitosamente.";
    } catch (PDOException $e) {
        echo "Error al eliminar el usuario: " . $e->getMessage();
    }
}

    if ($exists) {
        // Actualización de los datos
        $sql = "UPDATE Alumnos SET Nombre = ?, Apellido = ?, Dirección = ?, Grado = ?, Calificaciones = ?, Asistencia = ?, Profesor = ?, Año = ? WHERE Documento = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$nombre, $apellido, $direccion, $grado, $calificaciones, $asistencia, $profesor, $año, $documento]);
    }

    header('Location: crud.php'); // Redirigir después de crear o actualizar
    exit();


?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario y Alumnos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        h2 {
            color: #333;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }
        input[type="text"], input[type="email"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #5cb85c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .action-buttons form {
            display: inline;
        }
        .update-button, .delete-button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
        .delete-button {
            background-color: #dc3545;
        }
        .update-button:hover {
            background-color: #0056b3;
        }
        .delete-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <h2>Registro de Usuario</h2>
    <form action="" method="post">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
        
        <label for="tipoUsuario">Tipo de Usuario:</label>
        <input type="text" id="tipoUsuario" name="tipoUsuario" required>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <input type="hidden" name="UsuarioID" id="UsuarioID">
        
        <input type="hidden" name="accion" value="crear">
        <input type="submit" value="Registrar">
    </form>

    <h2>Lista de Usuarios</h2>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Tipo de Usuario</th>
                <th>Email</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?php echo $usuario['UsuarioID']; ?></td>
                    <td><?php echo $usuario['Nombre']; ?></td>
                    <td><?php echo $usuario['TipoUsuario']; ?></td>
                    <td><?php echo $usuario['Email']; ?></td>
                    <td class="action-buttons">
                        <form action="" method="post" style="display:inline;">
                            <input type="hidden" name="UsuarioID" value="<?php echo $usuario['UsuarioID']; ?>">
                            <input type="hidden" name="nombre" value="<?php echo $usuario['Nombre']; ?>">
                            <input type="hidden" name="tipoUsuario" value="<?php echo $usuario['TipoUsuario']; ?>">
                            <input type="hidden" name="email" value="<?php echo $usuario['Email']; ?>">
                            <input type="hidden" name="accion" value="actualizar">
                            <button type="submit" class="update-button">Actualizar</button>
                        </form>
                        <form action="" method="post" style="display:inline;">
                            <input type="hidden" name="UsuarioID" value="<?php echo $usuario['UsuarioID']; ?>">
                            <input type="hidden" name="accion" value="eliminar">
                            <button type="submit" class="delete-button">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    